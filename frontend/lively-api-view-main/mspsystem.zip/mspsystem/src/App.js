import React from "react";
// import CreateTicket from "./components/CreateTicket";
import MainDashboard from "./components/MainDashboard";

function App() {
  return (
    <div>
      {/* <h1>IT Ticketing System</h1>
      <CreateTicket />
      <hr /> */}
      <MainDashboard />
    </div>
  );
}

export default App;
