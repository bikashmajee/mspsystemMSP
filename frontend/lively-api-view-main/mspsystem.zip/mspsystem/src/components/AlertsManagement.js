import React, { useState, useEffect } from 'react';
import axios from 'axios';

export default function AlertsManagement() {
  const [alerts, setAlerts] = useState([]);
  const [newAlert, setNewAlert] = useState({ alertType: '', description: '' });

  useEffect(() => {
    fetchAlerts();
  }, []);

  const fetchAlerts = async () => {
    try {
      const res = await axios.get('http://localhost:8080/api/alerts');
      setAlerts(res.data);
    } catch (error) {
      console.error("Error fetching alerts", error);
    }
  };

  const createAlert = async () => {
    if (!newAlert.alertType || !newAlert.description) return alert("Fill alert type and description");
    try {
        console.log(newAlert)
      await axios.post('http://localhost:8080/api/alerts', newAlert);
      setNewAlert({ alertType: '', description: '' });
      fetchAlerts();
    } catch (error) {
      console.error("Error creating alert", error);
    }
  };

  const resolveAlert = async (id) => {
    try {
      await axios.post(`http://localhost:8080/api/alerts/${id}/resolve`);
      fetchAlerts();
    } catch (error) {
      console.error("Error resolving alert", error);
    }
  };

  return (
    <div>
      <h3>Alerts Management</h3>
      <input
        placeholder="Alert Type"
        value={newAlert.alertType}
        onChange={e => setNewAlert({ ...newAlert, alertType: e.target.value })}
      />
      <input
        placeholder="Description"
        value={newAlert.description}
        onChange={e => setNewAlert({ ...newAlert, description: e.target.value })}
      />
      <button onClick={createAlert}>Create Alert</button>

      <ul>
        {alerts.map(alert => (
          <li key={alert.id}>
            <b>{alert.alertType}:</b> {alert.description} - {alert.resolved ? 'Resolved' : 'Pending'}
            {!alert.resolved && <button onClick={() => resolveAlert(alert.id)}>Resolve</button>}
          </li>
        ))}
      </ul>
    </div>
  );
}
