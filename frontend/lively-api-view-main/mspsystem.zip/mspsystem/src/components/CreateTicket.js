import React, { useState } from "react";

export default function CreateTicket() {
  const [description, setDescription] = useState("");
  const [email, setEmail] = useState("");

  async function createTicket() {
    const data = { description, assignedEmployeeEmail: email };
    const res = await fetch("http://localhost:8080/api/tickets", {
      method: "POST",
      headers: {"Content-Type": "application/json"},
      body: JSON.stringify(data),
    });
    if (res.ok) {
      alert("Ticket created!");
      setDescription("");
      setEmail("");
    } else {
      alert("Failed to create ticket");
    }
  }

  return (
    <div>
      <h2>Create Ticket</h2>
      <input
        placeholder="Description"
        value={description}
        onChange={(e) => setDescription(e.target.value)}
      />
      <input
        placeholder="Assign to Employee Email"
        value={email}
        onChange={(e) => setEmail(e.target.value)}
        type="email"
      />
      <button onClick={createTicket}>Create</button>
    </div>
  );
}
