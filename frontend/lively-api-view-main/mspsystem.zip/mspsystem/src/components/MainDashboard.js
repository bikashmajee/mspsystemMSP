import React from 'react';
import CreateTicket from './CreateTicket';
import TicketDashboard from './TicketDashboard';
import AlertsManagement from './AlertsManagement';
import PatchJobManagement from './PatchJobManagement';

export default function MainDashboard() {
  return (
    <div style={{ display: 'flex', gap: 20 }}>
      <div style={{ flex: '1 1 50%' }}>
        <h2>Create Ticket</h2>
        <CreateTicket />
        <h2>Ticket Dashboard</h2>
        <TicketDashboard />
      </div>
      <div style={{ flex: '1 1 50%' }}>
        <AlertsManagement />
        <PatchJobManagement />
      </div>
    </div>
  );
}
