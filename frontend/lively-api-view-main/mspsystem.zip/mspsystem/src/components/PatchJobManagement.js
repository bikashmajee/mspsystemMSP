import React, { useState, useEffect } from 'react';
import axios from 'axios';

export default function PatchJobManagement() {
  const [patchJobs, setPatchJobs] = useState([]);
  const [newJob, setNewJob] = useState({ patchName: '', scheduleTime: '' });

  useEffect(() => {
    fetchPatchJobs();
  }, []);

  const fetchPatchJobs = async () => {
    try {
      const res = await axios.get('http://localhost:8080/api/patchjobs');
      setPatchJobs(res.data);
    } catch (error) {
      console.error("Error fetching patch jobs", error);
    }
  };

  const createPatchJob = async () => {
    if (!newJob.patchName || !newJob.scheduleTime) return alert("Fill patch name and schedule time");
    try {
      await axios.post('http://localhost:8080/api/patchjobs', null, { params: newJob });
      setNewJob({ patchName: '', scheduleTime: '' });
      fetchPatchJobs();
    } catch (error) {
      console.error("Error creating patch job", error);
    }
  };

  return (
    <div>
      <h3>Patch Job Scheduling</h3>
      <input
        placeholder="Patch Name"
        value={newJob.patchName}
        onChange={e => setNewJob({ ...newJob, patchName: e.target.value })}
      />
      <input
        type="datetime-local"
        value={newJob.scheduleTime}
        onChange={e => setNewJob({ ...newJob, scheduleTime: e.target.value })}
      />
      <button onClick={createPatchJob}>Schedule Patch</button>

      <ul>
        {patchJobs.map(job => (
          <li key={job.id}>
            <b>{job.patchName}</b> - Scheduled for: {new Date(job.scheduledTime).toLocaleString()} - Status: {job.status}
          </li>
        ))}
      </ul>
    </div>
  );
}
