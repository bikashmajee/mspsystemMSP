import React, { useEffect, useState } from "react";

export default function TicketDashboard() {
  const [tickets, setTickets] = useState([]);

  async function fetchTickets() {
    const res = await fetch("http://localhost:8080/api/tickets");
    const data = await res.json();
    setTickets(data);
  }

  useEffect(() => {
    fetchTickets();
    const interval = setInterval(fetchTickets, 60000);
    return () => clearInterval(interval);
  }, []);

  async function toggleComplete(id, completed) {
    await fetch(`http://localhost:8080/api/tickets/${id}/complete?completed=${!completed}`, {
      method: "PUT",
    });
    fetchTickets();
  }

  async function escalateNow(ticketId) {
  const res = await fetch(`http://localhost:8080/api/tickets/${ticketId}/escalate`, {
    method: "POST"
  });

  if (res.ok) {
    alert("Escalation email sent!");
    fetchTickets(); // Refresh ticket data if needed
  } else {
    alert("Failed to escalate");
  }
}

  return (
    <div>
      <h2>Ticket Dashboard</h2>
      <table border="1" cellPadding={5}>
        <thead>
          <tr>
            <th>ID</th>
            <th>Description</th>
            <th>Assigned To</th>
            <th>Created</th>
            <th>Completed</th>
            <th>Escalated</th>
            <th>Action</th>
          </tr>
        </thead>
        <tbody>
          {tickets.map((t) => (
            <tr key={t.id}>
              <td>{t.id}</td>
              <td>{t.description}</td>
              <td>{t.assignedEmployeeEmail}</td>
              <td>{new Date(t.createdTime).toLocaleString()}</td>
              <td>{t.completed ? "Yes" : "No"}</td>
              <td><button onClick={() => escalateNow(t.id)}>Escalate Now</button>
</td>
              <td>
                <button onClick={() => toggleComplete(t.id, t.completed)}>
                  {t.completed ? "Reopen" : "Complete"}
                </button>
              </td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
